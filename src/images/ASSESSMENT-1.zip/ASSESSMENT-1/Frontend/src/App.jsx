import React from "react";
import { Route, Routes } from "react-router-dom";
import Form from "./pages/Form";
import Home from "./pages/Home";
import { Toaster } from "react-hot-toast";

function App() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Form />} />
        <Route path="/home" element={<Home />} />
      </Routes>
      <Toaster />
    </>
  );
}

export default App;
