import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router";
import toast from "react-hot-toast";

function LoginForm({ switchToSignup }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post("/api/v1/login", {
        username,
        password,
      });
      localStorage.setItem("token", response.data.token);
      localStorage.setItem("username", response.data.user.username);
      setUsername("");
      setPassword("");
      navigate("/home");
      toast.success("Login successful!");
    } catch (error) {
      console.error("Login Error:", error.response);
      const errorMessage = error.response?.data.message || "Login failed";
      setError(errorMessage);

      if (errorMessage === "User is not registered") {
        switchToSignup();
        toast.error("User is not registered, please sign up.");
      } else {
        toast.error(errorMessage);
      }
    }
  };

  return (
    <div className="w-full bg-gray-800 shadow-md rounded-lg px-8 pt-6 pb-8 mb-4 mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center text-white">
        Login to your account
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label
            className="block text-white text-sm font-bold mb-2"
            htmlFor="username"
          >
            Username
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-white bg-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="username"
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="mb-6">
          <label
            className="block text-white text-sm font-bold mb-2"
            htmlFor="password"
          >
            Password
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-200 bg-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
            id="password"
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {error && <p className="text-red-500 text-center">{error}</p>}
        <div className="flex items-center justify-center">
          <button
            className="bg-gray-700 hover:bg-gray-800 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
            type="submit"
          >
            Login
          </button>
        </div>
      </form>
      <div className="mt-4 text-center">
        <a
          href="#!"
          onClick={switchToSignup}
          className="text-white hover:underline"
        >
          Don't have an account? Sign up here.
        </a>
      </div>
    </div>
  );
}

export default LoginForm;
