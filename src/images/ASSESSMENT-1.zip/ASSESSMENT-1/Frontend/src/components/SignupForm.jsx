import React, { useState } from "react";
import axios from "axios";
import toast from "react-hot-toast";

function SignupForm({ switchToLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post("/api/v1/signup", {
        username,
        password,
      });
      localStorage.setItem("username", response.data.user.username);
      switchToLogin();
      toast.success("Signup successful!");
    } catch (error) {
      console.error("Signup Error:", error.response);
      const errorMessage = error.response?.data.message || "Signup failed";
      setError(errorMessage);

      if (errorMessage === "User already Exist") {
        switchToLogin();
        toast.error("User already exists, please log in.");
      } else {
        toast.error(errorMessage);
      }
    }
  };

  return (
    <div className="w-full bg-gray-800 shadow-md rounded-lg px-8 pt-6 pb-8 mb-4 mx-auto">
      <h2 className="text-2xl font-bold mb-6 text-center text-white">
        Create an account
      </h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label
            className="block text-white text-sm font-bold mb-2"
            htmlFor="username"
          >
            Username
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-200 bg-gray-700 leading-tight focus:outline-none focus:shadow-outline"
            id="username"
            type="text"
            placeholder="Username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className="mb-6">
          <label
            className="block text-white text-sm font-bold mb-2"
            htmlFor="password"
          >
            Password
          </label>
          <input
            className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-200 bg-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline"
            id="password"
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </div>
        {error && <p className="text-red-500 text-center">{error}</p>}
        <div className="flex items-center justify-center">
          <button
            className="bg-gray-700 hover:bg-gray-800 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
            type="submit"
          >
            Sign Up
          </button>
        </div>
      </form>
      <div className="mt-4 text-center">
        <a
          href="#!"
          onClick={switchToLogin}
          className="text-white hover:underline"
        >
          Already have an account? Log in here.
        </a>
      </div>
    </div>
  );
}

export default SignupForm;
