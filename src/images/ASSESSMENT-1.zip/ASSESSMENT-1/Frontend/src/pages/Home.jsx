import React from "react";
import toast from "react-hot-toast";
import { useNavigate } from "react-router";

function Home() {
  const username = localStorage.getItem("username");
  const navigate = useNavigate();
  const handleLogOut = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    navigate("/");
    toast.success("Log Out successfull !!");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-900 text-white flex-col gap-6">
      <div className="text-center px-8 py-6 bg-gray-800 shadow-lg rounded-lg">
        <h1 className="text-2xl font-bold">
          Welcome to the Home Page, {username ? username : "User"}!
        </h1>
      </div>

      <div>
        <button
          className="bg-gray-700 hover:bg-gray-800 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline w-full"
          onClick={handleLogOut}
        >
          LogOut
        </button>
      </div>
    </div>
  );
}

export default Home;
