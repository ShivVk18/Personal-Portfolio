import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import LoginForm from "../components/LoginForm";
import SignupForm from "../components/SignupForm";

function Form() {
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const navigate = useNavigate();

  const loginClickHandler = () => {
    setIsLoggedIn(true);
  };

  const signupClickHandler = () => {
    setIsLoggedIn(false);
  };

  return (
    <div className="flex items-center justify-center w-full h-screen bg-gray-900 text-white">
      <div className="w-full max-w-md">
        <div className="mb-8">
          <div className="inline-flex rounded-md shadow-sm" role="group">
            <button
              onClick={loginClickHandler}
              className={`px-4 py-2 text-sm font-medium rounded-l-md ${
                isLoggedIn
                  ? "text-white bg-gray-700 hover:bg-gray-800"
                  : "text-gray-400 bg-gray-800 hover:bg-gray-700"
              } border border-gray-600 focus:z-10 focus:ring-2 focus:ring-gray-500 focus:text-gray-200`}
            >
              Login
            </button>
            <button
              onClick={signupClickHandler}
              className={`px-4 py-2 text-sm font-medium rounded-r-md ${
                !isLoggedIn
                  ? "text-white bg-gray-700 hover:bg-gray-800"
                  : "text-gray-400 bg-gray-800 hover:bg-gray-700"
              } border border-gray-600 focus:z-10 focus:ring-2 focus:ring-gray-500 focus:text-gray-200`}
            >
              Signup
            </button>
          </div>
        </div>

        {isLoggedIn ? (
          <LoginForm switchToSignup={signupClickHandler} />
        ) : (
          <SignupForm switchToLogin={loginClickHandler} />
        )}
      </div>
    </div>
  );
}

export default Form;
